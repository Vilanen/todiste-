# My-secret-diary-
A secret diary web app using PHP and Mysql.

Create a database and change connection in connection.php after it uploads all file on a server and create your account to write something.also You can try on http://www.rsinghal26.gq/diary/index.php  


