<footer>
    <div class="container">

      <div class="row">
        <div class="col-sm-8 margin-20">
          <ul class="list-inline social">
            <li>Connect with us on</li>
            <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
          </ul>
        </div>

        <div class="col-sm-4 text-right">
          <p><small>Copyright &copy; 2014. All rights reserved. <br>
              Created by <a href="http://visualsoldiers.com">Visual Soldiers</a></small></p>
        </div>
      </div>

    </div>
  </footer>