<?php

$dbServername = "mysql.metropolia.fi";
$dbUsername = "mariamv";
$dbPassword = "A1793159357a";
$dbName = "mariamv";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);